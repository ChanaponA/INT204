package sit.int204.classicmodelsservice.dtos;


import lombok.Getter;
import lombok.Setter;
import sit.int204.classicmodelsservice.entities.Office;


@Setter
public class SimpleEmployeeDTO {
    private String lastName;
    private String firstName;
    private Office office;
    public Office getOffice(){
        return office;
    }
    public String getFullName() {
        return firstName + ' '+ lastName;
    }
}
