package sit.int204.classicmodelsservice.properties;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;

@ConfigurationProperties(prefix = "file")
@Getter
@Setter
@Data
public class FileStorageProperties {
//    file.upload-dir=./product-images
//    file.file-service-host-name=minio-service.sit.kmutt.ac.th
    private String uploadDir;
    private String fileServiceHostName ;
}
