package sit.int204.classicmodelsservice.entities;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.*;

import java.util.List;

@Getter
@Setter
@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "customers")
public class Customera {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
    @Column(name = "customerName", nullable = false, length = 50)
    private String customerName;
    @Column(name = "contactLastName", nullable = false, length = 50)
    private String contactLastName;
    @Column(name = "contactFirstName", nullable = false, length = 50)
    private String contactFirstName;
    @Column(name = "phone", length = 50)
    private String phone;
    @Column(name = "addressLine1", length = 50)
    private String addressLine1;
    @Column(name = "addressLine2", nullable = false, length = 50)
    private String city;
    @Column(name = "city", nullable = false, length = 15)
    private String state;
    @Column(name = "postalCode", nullable = false, length = 50)
    private String postalCode;
    @Column(name = "country", nullable = false, length = 50)
    private String country;
    @Column(name = "salesRepEmployeeNumber", nullable = false, length = 50)
    private String salesRepEmployeeNumber;
    @Column(name = "creditLimit", nullable = false, length = 50)
    private String creditLimit;
    @JsonIgnore
    @OneToMany(mappedBy = "customerNumber")
    private List<Order> OrderList ;
}
