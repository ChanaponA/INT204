package sit.int204.classicmodelsservice.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import sit.int204.classicmodelsservice.Service.CustomeraService;
import sit.int204.classicmodelsservice.entities.Customera;
import sit.int204.classicmodelsservice.entities.Order;

import java.util.List;

@RestController
@RequestMapping("/customera")
public class CustomeraController {
    @Autowired
    private CustomeraService service;

    @GetMapping("")
    public List<Customera> getAllCustomera(@RequestParam(required = false) String city) {
        return service.getAllCustomera(city);
    }

    @GetMapping("/{id}")
    public Customera getCustomeraById(@PathVariable Long id) {
        return service.findByID(id);
    }

    @GetMapping("/{id}/orders")
    public List<Order> getCustomeraOrder(@PathVariable Long id) {
        System.out.println("id = "+ id);
        return service.findByID(id).getOrderList();
    }

//    @PostMapping("")
//    public Customera addNewCustomera(@RequestBody Customera Customera) {
//        return service.createNewCustomera(Customera);
//    }

    @PostMapping("/insert")
    public List<Customera> addNewCustomera(@RequestBody List<Customera> Customera) {
        return service.insertCustomera(Customera);
    }

    @PutMapping("/{id}")
    public Customera updateCustomera(@RequestBody Customera Customera, @PathVariable Long id) {
        return service.updateCustomera(id, Customera);
    }

    @DeleteMapping("/{id}")
    public void removeCustomera(@PathVariable Long id) {
        service.removeCustomera(id);
    }
}
