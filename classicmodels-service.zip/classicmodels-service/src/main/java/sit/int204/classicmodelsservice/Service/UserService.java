package sit.int204.classicmodelsservice.Service;

import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import sit.int204.classicmodelsservice.entities.User;
import sit.int204.classicmodelsservice.repositories.UserRepository;

@Service
public class UserService {
    @Autowired
    private UserRepository repository;
    public User getId(String id) {
        return repository.findById(id).orElseThrow(
                () -> new HttpClientErrorException(HttpStatus.NOT_FOUND,
                        "Office Id " + id + " DOES NOT EXIST !!!") {
                }
        );
    }
    @Transactional
    public User createNewUser(User user) {
        return repository.save(user);
    }
    @Transactional
    public void removeUser(String id) {
        User user = repository.findById(id).orElseThrow(
                () -> new HttpClientErrorException(HttpStatus.NOT_FOUND, "Office Id " + id + " DOES NOT EXIST !!!")
        );
        repository.delete(user);
    }
    @Transactional
    public User updateUser(String id, User user) {
        if(user.getId()!=null && !user.getId().trim().isEmpty()) {
            if (!user.getId().equals(id)) {
                throw new HttpClientErrorException(HttpStatus.BAD_REQUEST,
                        "Conflict Office code !!! (" + id + " vs " + user.getId() + ")");
            }
        }
        User existingUser = repository.findById(id).orElseThrow(() -> new HttpClientErrorException(HttpStatus.NOT_FOUND, "Office Id " + id + " DOES NOT EXIST !!!"));
        return repository.save(user);
    }
}
