package sit.int204.classicmodelsservice.Service;


import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;
import sit.int204.classicmodelsservice.dtos.NewCustomerDto;
import sit.int204.classicmodelsservice.entities.Customer;
import sit.int204.classicmodelsservice.repositories.CustomerRepository;

import java.util.List;


@Service
public class CustomerService {
    @Autowired
    private CustomerRepository repository;
    @Autowired
    private ListMapper listMapper;
    @Autowired
    private ModelMapper mapper;

    public Customer findByID(Integer id) {
        return repository.findById(id).orElseThrow(
                () -> new ResponseStatusException(HttpStatus.NOT_FOUND,
                        "Customer number '" + id + "' does not exist !!!!"));
    }

    @Transactional
    public Customer createNewCustomer(Customer customer) {
        return repository.save(customer);
    }

    @Transactional
    public void removeCustomer(Integer id) {
        Customer customer = repository.findById(id).orElseThrow(
                () -> new ResponseStatusException(HttpStatus.NOT_FOUND,
                        "Customer number '" + id + "' does not exist !!!!"));
        repository.delete(customer);
    }

    @Transactional
    public Customer updateCustomer(Integer id, Customer customer) {
        if (customer.getId() != null && !customer.getId().toString().isEmpty()) {
            if (!customer.getId().equals(id)) {
                throw new ResponseStatusException(HttpStatus.BAD_REQUEST,
                        "Conflict Customer number !!! (" + id + " vs " + customer.getId() + ")");
            }
        }
        Customer existingCustomer = repository.findById(id).orElseThrow(
                () -> new ResponseStatusException(HttpStatus.NOT_FOUND,
                        "Customer number '" + id + "' does not exist !!!!"));
        return repository.save(customer);
    }

    public NewCustomerDto createCustomer(NewCustomerDto newCustomer) {
        if (repository.existsById(newCustomer.getId())) {
            throw new ResponseStatusException(HttpStatus.CONFLICT, "Duplicate customer for id " +
                    newCustomer.getCustomerName());
        }
        Customer customer = mapper.map(newCustomer, Customer.class);
        return mapper.map(repository.saveAndFlush(customer), NewCustomerDto.class);
    }

    public List<NewCustomerDto> getAllCustomers() {
        return listMapper.mapList(repository.findAll(), NewCustomerDto.class, mapper);
    }

}
