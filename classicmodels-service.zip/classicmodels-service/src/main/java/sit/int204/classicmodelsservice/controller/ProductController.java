package sit.int204.classicmodelsservice.controller;

import jakarta.validation.constraints.Min;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.context.request.WebRequest;

import sit.int204.classicmodelsservice.exceptions.ErrorResponse;
import sit.int204.classicmodelsservice.exceptions.ItemNotFoundException;
import sit.int204.classicmodelsservice.Service.ListMapper;
import sit.int204.classicmodelsservice.Service.ProductService;
import sit.int204.classicmodelsservice.dtos.VerySimpleProductDTO;
import sit.int204.classicmodelsservice.entities.Product;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/products")
public class ProductController {
    @Autowired //ทำ dependancy ดึง object มาใช้
    private ProductService service;
    @Autowired
    private ListMapper listMapper;
    @Autowired
    private ModelMapper modelMapper;
    @GetMapping("")
    public ResponseEntity<Object> findAllProduct(@RequestParam(defaultValue = "0") Double lower,
                                                 @RequestParam(defaultValue = "0") Double upper,
                                                 @RequestParam(defaultValue = "") String productName,
                                                 @RequestParam(defaultValue = "") String[] sortBy,
                                                 @RequestParam(defaultValue = "") String[] direction,
                                                 @RequestParam(defaultValue = "0") @Min(0)int pageNo,
                                                 @RequestParam(defaultValue = "0") @Min(10) int pageSize) {
        Page<Product> productPage = service.getProduct(lower, upper, productName, sortBy, direction, pageNo, pageSize);
        return ResponseEntity.ok(listMapper.toPageDTO(productPage, VerySimpleProductDTO.class));
    }

    @GetMapping("/product-line/{id}")
    public ResponseEntity<Object> getProductsByCategory(@PathVariable String id) {
        List <Product> productList = service.getProductsByCategory(id);
        List< VerySimpleProductDTO> vsp = productList.stream().map(product -> modelMapper.map(product, VerySimpleProductDTO.class)).collect(Collectors.toList());
        return ResponseEntity.ok(vsp);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Object> getProductById(@PathVariable String id) {
        return ResponseEntity.ok(service.getProductById(id));
    }




//    @ExceptionHandler(ItemNotFoundException.class)
//    @ResponseStatus(code = HttpStatus.NOT_FOUND)
//    public ResponseEntity<ErrorResponse>
//    handleItemNotFound(ItemNotFoundException ex, WebRequest request) {
//        ErrorResponse er = new
//                ErrorResponse(HttpStatus.NOT_FOUND.value(), ex.getMessage(),
//                request.getDescription(false));
//        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(er);
//    }

}
