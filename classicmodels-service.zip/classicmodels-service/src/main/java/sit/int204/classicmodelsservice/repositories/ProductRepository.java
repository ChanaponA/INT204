package sit.int204.classicmodelsservice.repositories;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import sit.int204.classicmodelsservice.entities.Product;

import java.util.List;

public interface ProductRepository extends JpaRepository<Product, String> {
    List<Product> findByBuyPriceBetweenAndProductNameContains(Double lower, Double upper, String productName);
    List<Product> findByProductNameContains(String productName);
    List<Product> findByProductLineStartingWith(String productLine);

    @Query("SELECT p FROM Product p WHERE p.productLine like :category")
    List<Product> getProductsByCategory(String category);

    Product findFirstByOrderByPriceDesc();
    List<Product> findByPriceBetweenAndProductNameContains(Double lower, Double upper, String partOfProduct);
    List<Product> findByPriceBetweenAndProductNameContains(Double lower, Double upper, String partOfProduct, Sort by);
    Page<Product> findByPriceBetweenAndProductNameContains(Double lower, Double upper, String productName, Pageable pageable);

}
