package sit.int204.classicmodelsservice.Service;


import jakarta.transaction.Transactional;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import sit.int204.classicmodelsservice.models.Student;


@Service
public class StudentService {

    @Transactional
    public Student calGrade(Student student) {
        if (student.getId() == null || student.getId().trim().isEmpty()) {
            throw new HttpClientErrorException(HttpStatus.BAD_REQUEST,
                    "Student score is required !!!");
        }
        return student.CalculatorGrade();
    }


}
