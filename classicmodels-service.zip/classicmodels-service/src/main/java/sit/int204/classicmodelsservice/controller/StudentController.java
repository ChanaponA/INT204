package sit.int204.classicmodelsservice.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import sit.int204.classicmodelsservice.Service.OfficeService;
import sit.int204.classicmodelsservice.Service.StudentService;
import sit.int204.classicmodelsservice.entities.Office;
import sit.int204.classicmodelsservice.models.Student;

@RestController
@RequestMapping("/api/students")
public class StudentController {
    @Autowired
    private StudentService service;

    @PostMapping("")
    public Student calGrade(@RequestBody Student student) {
        return service.calGrade(student);
    }
}
