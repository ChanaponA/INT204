package sit.int204.classicmodelsservice.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;
import sit.int204.classicmodelsservice.entities.Customera;
import sit.int204.classicmodelsservice.repositories.CustomeraRepository;

import java.util.List;

@Service
public class CustomeraService {
    @Autowired
    private CustomeraRepository repository;
    public List<Customera> getAllCustomera() {
        return repository.findAll();
    }
    public List<Customera> getAllCustomera(String city) {
        if (city == null || city.isEmpty()) {
            return repository.findAll();
        } else {
            return repository.findByCityContains(city);
        }
    }
    public Customera findByID(Long id) {
        return repository.findById(id).orElseThrow(
                ()->new ResponseStatusException(HttpStatus.NOT_FOUND,
                "Customer number '"+ id + "' does not exist !!!!"));
    }
    public List<Customera> insertCustomera(List<Customera> customeras) {
        return repository.saveAll(customeras);
    }

    @Transactional
    public Customera createNewCustomera(Customera customera) {
        return repository.save(customera);
    }
    @Transactional
    public void removeCustomera(Long id) {
        Customera customera = repository.findById(id).orElseThrow(
                ()->new ResponseStatusException(HttpStatus.NOT_FOUND,
                "Customer number '"+ id + "' does not exist !!!!"));
        repository.delete(customera);
    }
    @Transactional
    public Customera updateCustomera(Long id, Customera customera) {
        if(customera.getId()!=null && !customera.getId().toString().isEmpty()) {
            if (!customera.getId().equals(id)) {
                throw new ResponseStatusException(HttpStatus.BAD_REQUEST,
                        "Conflict Customer number !!! (" + id + " vs " + customera.getId() + ")");
            }
        }
        Customera existingCustomera = repository.findById(id).orElseThrow(
                ()->new ResponseStatusException(HttpStatus.NOT_FOUND,
                "Customer number '"+ id + "' does not exist !!!!"));
        return repository.save(customera);
    }
}
